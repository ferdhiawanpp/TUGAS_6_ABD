<?php

namespace App\Entities;

use CodeIgniter\Entity;

class StatusEntity extends Entity
{
}
